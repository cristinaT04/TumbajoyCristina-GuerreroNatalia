package com.clinicaodontologica.proyectointegradorfinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoIntegradorFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoIntegradorFinalApplication.class, args);
	}

}
