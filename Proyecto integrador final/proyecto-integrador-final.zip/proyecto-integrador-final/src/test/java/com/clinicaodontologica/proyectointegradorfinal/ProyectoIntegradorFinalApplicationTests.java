package com.clinicaodontologica.proyectointegradorfinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoIntegradorFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
